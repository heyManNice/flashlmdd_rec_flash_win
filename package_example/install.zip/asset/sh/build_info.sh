BUILD_DEVICE="flashlmdd"
BUILD_MODEL="LGV500N"
BUILD_GITHUB="https://github.com/heyManNice/flashlmdd_rec_flash_win"
BUILD_DATE="周三 2024/08/14 21:48:20.17"
